var $pi = $("#product_code");
var $prod;
var $total = 0;
$pi.blur(function() {
    if($pi.val().length > 3){
        $("#product_qty").prop('disabled', true);
        $("#product_price").prop('disabled', true);
        $("#product_code").prop('disabled', true);
        $.ajax({
            type:"get",
            url: "/products/get-product/" + $pi.val()
        }).done(function(data){
            if (data.length > 0){
                $prod = data[0];
                $("#prod_info").html("<em>" + data[0].slug + "</em> <span>" +
                data[0].description + "</span> $" + data[0].price);
                $("#product_price").val(data[0].price);
                $prod.qty = $("#product_qty").val();
            } else {
                $prod = {};
                var $r = confirm("Este articulo no existe, desea agregarlo a la nota?");
                if ($r == true){
                    $prod.slug = $("#product_code").val()
                    $prod.description = "Articulo de venta";
                    $prod.price = $("#product_price").val();
                    $prod.qty = $("#product_qty").val();
                }
            }
                $("#product_qty").prop('disabled', false);
                $("#product_price").prop('disabled', false);
                $("#product_code").prop('disabled', false);
                $("#product_price").focus();
        });
    }
});

var $pp = $("#product_price").keyup(function(e){
    if(e.keyCode == 13){
        var $data = dataView.getItems();
        var $id = 0;
        if ($data.length == 0){
            $id = 0;
        }
        else {
            $id = +$data[$data.length-1].id;
            $id++;
        }
        $prod.qty = $("#product_qty").val();
        $data.push({'id': $id, 'slug': $prod.slug, 'desc': $prod.description,
        'price': $("#product_price").val(), 'qty': $prod.qty});
        dataView.setItems($data);
        $("#product_code").val("");
        $("#product_code").focus();
        $("#product_price").val("");
        grid_get_total();
    }
});

var $mrs = $("#menu_reports_sales");
$mrs.click(function(e){
    e.preventDefault();
    var $branch = $("#select_branches")[0].options[$("#select_branches")[0].selectedIndex].value;
    var $now;
    $.ajax({
        dataType:"jsonp",
        url:"//www.timeapi.org/utc/now.json",
        success:function(d){
                var $utc = new Date(d.dateString);
                $now = new Date(d.dateString);
                $now.setHours($utc.getHours() - 6);
                $.ajax({
                    url:"/pos/report-sales/" + $branch + "/" + $now.getDate() + "-" + (+$now.getMonth() + 1) + "-" + $now.getFullYear() + "/",
                    success:function(d){
                        console.log("here");
                        if (!notReady()) {
                            qz.append($branch + "\n\r");
                            var $total = 0;
                            if (d.sales.length > 0){
                                qz.append(d.sales[0].date_time.split(" ")[0] + "\n\r");
                                qz.append("Folio   Total    Metodo\n\r");
                                for (var i = 0; i < d.sales.length; i++){
                                var $sale = d.sales[i];
                                qz.append($sale.folio_number + " " + $sale.total_amount + " " + $sale.payment_method + "\n\r");
                                $total += +$sale.total_amount;
                                }
                            }
                        qz.append("Total del dia: " + $total + "\n\r");
                        qz.append("\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r");
                        qz.append(chr(27) + chr(105));
                        qz.append("\x1B\x69");
                        qz.print();
                        } else {
                            window.alert("Hay un error con la impresora. Presione la tecla F5 en el teclado y si aparece una ventana gris seleccione el recuadro que esta en la parte de abajo para que se aparezca una paloma y despues el boton que dice 'Run...'");
                        }
                    }
                });
            }
    }); 
});

function grid_get_total(){
    var $data = dataView.getItems();
    var $total = 0;
    for(var i = 0; i < $data.length; i++){
        var item = $data[i];
        $total = +$total + (+item.price * +item.qty);
    }
    $("#grid_totals").html("<strong>Total:</strong> <span id='nota_sub_total'>"  + $total + "</span>");
}

$("#nota").on('shown.bs.modal', function(e){
    $("#nota_pago").keyup(function(e){
        if(e.keyCode == 9 || e.keyCode == 13){
            var $cambio = $("#nota_pago").val() - $("#nota_total").val();
            $("#nota_cambio").val($cambio);
        }
    });

    $("#nota_pago").focus(function(){
        this.select();
    });
    $("#nota_pago").focus();
});

$("#btn_pagar").click(function(e){
    var $total = $("#nota_sub_total")[0].innerHTML;
    $("#nota_pago").val($total); 
    $("#nota_total").val($total);
    $("#nota_total").prop("disabled", true);
    $("#nota_cambio").prop("disabled", true);
});

$("#save_ticket").submit(function(e){
    e.preventDefault();
    var $now;
    $.ajax({
        dataType:"jsonp",
        url:"//www.timeapi.org/utc/now.json",
        success:function(d){
                var $utc = new Date(d.dateString);
                $now = new Date(d.dateString);
                $now.setHours($utc.getHours() - 6);
            }
    });
    $("#nota_btn_imprimir").prop("disabled", true);
    var $td = JSON.stringify(dataView.getItems());
    var $cp = $("#nota_pago").val();
    var $tp = $("#nota_tipo_pago").val();
    var $branch = $("#select_branches")[0].options[$("#select_branches")[0].selectedIndex].value;
    var $data = {data:"{\"user\":\"" + $user +"\", "+ 
                       "\"branch\":\"" + $branch + "\", "+ 
                       "\"details\":" + $td +", "+ 
                       "\"payment_type\": \"" + $tp + "\", "+ 
                       "\"payment_amount\":\"" + $cp +"\"}" };
    var csrftoken = balco.get_cookie('csrftoken');
    csrftoken = balco.get_cookie('csrftoken');
    $.ajax({
        crossDomain: false,
        beforeSend: function(xhr, settings){
            xhr.setRequestHeader("X-CSRFToken", csrftoken);
        },
        type:"post",
        url: "/pos/save-sale",
        data: $data,
        error: function(jqXHR, textStatus, errorThrown){
            console.log(jqXHR);
            console.log(textStatus);
            console.log(errorThrown);
        }
    }).done(function(data){
            var $folio = data.folio;
            var $total = 0;
            if (!notReady()) {
            qz.append(data.ticket_pre);
            qz.append("\n\r");
            if (!$now){
                $now = new Date();
            }
            qz.append('\n\r\t Fecha: ' + $now.getDate() + '/' 
                                       + (+$now.getMonth() + 1) + '/' 
                                       + $now.getFullYear() + '\n\r');
            qz.append('\n\r\t Folio: ' + $folio + '\n\r');
            for(var i =0; i < dataView.getItems().length; i++){
                var item = dataView.getItems()[i];
                $total += +item.price * +item.qty;
                qz.append("# \tCodigo\tPrecio\tCantidad\n\r\n\r");
                qz.append(item.id + " \t " + item.slug + " \t " + item.price + " \t " + item.qty + "\n\r");
                if (item.desc != ""){
                    qz.append("\t" + item.desc + "\n\r");
                } else {       
                    qz.append("\tArticulo de Venta\n\r");
                }
            }
            qz.append("Total: \t" + $total + "\n\t");
            qz.append("Su Pago: \t" + $cp + "\n\t");
            qz.append("Cambio: \t" + ($cp - $total).toFixed(2) + "\n\t");
            qz.append(data.ticket_post);
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append(chr(27) + chr(105));
            qz.append("\x1B\x69");
            /** COPIA 8*/
            qz.append('\n\r\t***COPIA***\t\n\r');
            qz.append(data.ticket_pre);
            qz.append("\n\r");
            qz.append('\n\r\t Fecha: ' + $now.getDate() + '/' 
                                       + (+$now.getMonth() + 1) + '/' 
                                       + $now.getFullYear() + '\n\r');
            qz.append('\n\r\t Folio: ' + $folio + '\n\r');
            for(var i =0; i < dataView.getItems().length; i++){
                item = dataView.getItems()[i];
                qz.append("# \tCodigo\tPrecio\tCantidad \n\r\n\r");
                qz.append(item.id + " \t " + item.slug + " \t " + item.price + " \t " + item.qty + "\n\r");
                qz.append("\t" + item.desc + "\n\r");
            }
            qz.append("Total: \t" + $total + "\n\t");
            qz.append("Su Pago: \t" + $cp + "\n\t");
            qz.append("Cambio: \t" + ($cp - $total).toFixed(2) + "\n\t");
            qz.append(data.ticket_post);
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append("\n\r");
            qz.append(chr(27) + chr(105));
            qz.append("\x1B\x69");
            qz.print();
            } else {
                window.alert("Hay un error con la impresora. Presione la tecla F5 en el teclado y si aparece una ventana gris seleccione el recuadro que esta en la parte de abajo para que se aparezca una paloma y despues el boton que dice 'Run...'");
            }
        var empty = [];
        dataView.setItems(empty);
        $("#nota").modal('hide');
        $("#product_code").focus();
        $("#grid_totals").html("<strong>Total:</strong> <span id='nota_sub_total'>0.0</span>");
        $("#nota_btn_imprimir").prop("disabled", false);
    });
});

